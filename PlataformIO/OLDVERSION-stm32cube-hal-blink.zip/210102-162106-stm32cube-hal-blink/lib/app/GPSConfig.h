#ifndef _GPSCONFIG_H_
#define _GPSCONFIG_H_

#define	_GPS_USART					huart2
#define	_GPS_DEBUG					0



#endif
