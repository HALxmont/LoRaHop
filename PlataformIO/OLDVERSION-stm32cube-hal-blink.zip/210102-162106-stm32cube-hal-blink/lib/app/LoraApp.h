#ifndef LORAAPP_H_
#define LORAAPP_H_
#include"stm32f1xx.h"

#define LED_PIN                                GPIO_PIN_13
#define LED_GPIO_PORT                          GPIOC
#define LED_GPIO_CLK_ENABLE()                  __HAL_RCC_GPIOC_CLK_ENABLE()
#define M1_LOW()                               HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, RESET);
#define M0_LOW()                               HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, RESET);
#define M1_HIGH()                              HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, SET);
#define M0_HIGH()                              HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, SET);
#define LRBuffSize 128
#define MNAME   Panda


uint8_t *txbufferLoRa;

typedef enum {appIDLE = 0, AppTransmitting, AppReceiving, AppConfiguration} AppStatus;
typedef enum {Normal  = 0, WakeUp, PowerDown, Program} ModuleStatus;

/*
1. First 2 bytes as upcounter
2. Random number generator
3. Frame length fixed ot not
4. Exceed 58 bytes of payload or no
5. 2 files Rx.txt and Tx.txt
6. PB12-14 as GPIO for status Led: GPS parsing data, LoRa frame received. 
*/


typedef struct{

    uint16_t addr;
    uint8_t  chan;
    uint8_t  dst;
    uint8_t  src;
    uint8_t  len;
    uint8_t  data[LRBuffSize];

} LoraMessage;

void LORA_UART_IDLECallback(UART_HandleTypeDef *huart);
uint8_t genByte(void);
void genPayload(void);
void sendFrameLoRa(void);
void  LoRa_Init(void);
void send_string(char* s);
#endif