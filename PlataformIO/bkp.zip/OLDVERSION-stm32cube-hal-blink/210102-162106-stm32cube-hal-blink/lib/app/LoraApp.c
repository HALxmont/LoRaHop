#include <stdlib.h>
#include <string.h>
#include "LoraApp.h"
#include "stm32f1xx.h"
#include "stm32f1xx_hal.h"
#include "GPS.h"

char LoRaRxBuff[LRBuffSize];
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;
extern UART_HandleTypeDef huart3;
extern DMA_HandleTypeDef dma2;

void LORA_UART_IDLECallback(UART_HandleTypeDef *huart)
{
	//Stop this DMA transmission
    HAL_UART_DMAStop(huart);         
    //Calculate the length of the received data
    uint8_t data_length  = LRBuffSize - __HAL_DMA_GET_COUNTER(&dma2);   
    HAL_UART_Transmit(&huart1,(uint8_t*) LoRaRxBuff,(uint16_t)data_length,0x700);  
	//Test function: Print out the received data
    HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_12);
    data_length = 0;
    //Restart to start DMA transmission of LRBuffSize bytes of data at a time
    HAL_UART_Receive_DMA(huart, (uint8_t*)LoRaRxBuff, LRBuffSize);                    
}

uint8_t genByte(void){

    uint8_t res;
        res = rand()%255;
    return res;
}

void genPayload(void){

    uint8_t length;
    txbufferLoRa = NULL;
    length = rand()%112;
    txbufferLoRa = (uint8_t*) malloc(length);
    if(txbufferLoRa != NULL){
        for(uint8_t i=2; i<length;i++)
            txbufferLoRa[i] = genByte();
    }
}

void sendFrameLoRa(void){

    static uint16_t counter;
    uint8_t tmp;
    genPayload();
    tmp = (uint8_t) counter >> 8;
    txbufferLoRa[0] = tmp;
    tmp = (uint8_t) counter;
    txbufferLoRa[1] = tmp;
    if(txbufferLoRa != NULL){
        HAL_UART_Transmit(&huart3, txbufferLoRa, sizeof(txbufferLoRa), 0x700);     
        counter++;
        free(txbufferLoRa);
    }
}
void  LoRa_Init(void){
    
    HAL_UART_Receive_DMA(&huart3, (uint8_t*)LoRaRxBuff, (uint16_t)LRBuffSize); 
}

void send_string(char* s){
	HAL_UART_Transmit(&huart1, (uint8_t*)s, strlen(s), 1000);
}