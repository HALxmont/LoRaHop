#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "stm32f1xx_hal.h"
#include "stm32f1xx_hal_dma.h"
#include"LoraApp.h"
#include "GPS.h"
#include "HardwareInit.h"
#include "fatfs.h"
#include "ff.h"
#include "main.h"

extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;
extern UART_HandleTypeDef huart3;
extern ExtIntStatus extIT;
extern char LoRaRxBuff[LRBuffSize];
extern DMA_HandleTypeDef dma1;
extern DMA_HandleTypeDef dma2;
extern GPS_t GPS;
extern SPI_HandleTypeDef  hspi;
SDStatus sdstat;

void myprintf(const char *fmt, ...) {
  static char buffer[256];
  __va_list args;
  va_start(args, fmt);
  vsnprintf(buffer, sizeof(buffer), fmt, args);
  va_end(args);

  int len = strlen(buffer);
  HAL_UART_Transmit(&huart1, (uint8_t*)buffer, len, -1);

}

int main(void)
{

  FATFS FatFs; 	//Fatfs handle
  FRESULT fres; //Result after operations
  //Let's get some statistics from the SD card
  DWORD free_clusters, free_sectors, total_sectors;
  FATFS* getFreeFs;
  
  SystemClock_Config();
  HardwareInit();
  MX_FATFS_Init();
  HAL_Delay(1);

  sdstat = 1;

  myprintf("Hello\r\n");
  //Open the file system
  fres = f_mount(&FatFs, "", 1); //1=mount now
  if (fres != FR_OK) {
  	myprintf("f_mount error (%i)\r\n", fres);  
    sdstat = 0;
  }
  fres = f_getfree("", &free_clusters, &getFreeFs);
  if (fres != FR_OK) {
  	  myprintf("f_getfree error (%i)\r\n", fres);
      sdstat = 0;
  }
  else{
    //Formula comes from ChaN's documentation
    total_sectors = (getFreeFs->n_fatent - 2) * getFreeFs->csize;
    free_sectors = free_clusters * getFreeFs->csize;
    myprintf("SD card stats:\r\n%10lu KiB total drive space.\r\n%10lu KiB available.\r\n", total_sectors / 2, free_sectors / 2);
    }

//    f_mount(NULL, "", 0);

__HAL_UART_ENABLE_IT(&huart3, UART_IT_IDLE);    
__HAL_UART_ENABLE_IT(&huart2, UART_IT_IDLE); 
  GPS_Init();
  LoRa_Init();
  
  while (1){
    HAL_Delay(4000);
    
    GPS_MakeString();
  }
}





